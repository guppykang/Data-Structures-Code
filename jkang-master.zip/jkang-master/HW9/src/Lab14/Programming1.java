package Lab14;

import java.util.Hashtable;

public class Programming1 <E>
{
	/*public static int findLocation(//a table and an object are passed in : table, and key)
	{
		int index = key.hashCode() % table.length;
		
		
		if(table[index] == null)
		{
			return -1;
		}
		
		//the key and the item we are trying to find are in the table
		else if(table[index].equals(key))
		{
			return index;
		}
		else
		{
			
			while(table[index] != null)
			{
				
				index = (index + 1)%table.length; 
				if(table[index].equals(key))
				{
					return table[index];
				}
				//stops if a null entry is found according to assignment or until the object is found
				else if( table[index] == null)
				{
					return -1;
				}
			}
		}
		return -1;
		
	}*/
}
