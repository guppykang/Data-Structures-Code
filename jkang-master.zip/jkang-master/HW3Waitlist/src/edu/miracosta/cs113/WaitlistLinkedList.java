package edu.miracosta.cs113;

import java.util.ArrayList;

/**
 * 
 * @author Joshua Kang
 * @version 3.0 
 * Program Name: Wait Lister Linked List
 * Program Description: Keeps track of a set of wait listers for a class. 
 * Class Invariant: n/a
 *
 */
public class WaitlistLinkedList 
{
	private class Node
	{
		private Student student;
		private Node next;
		
		public Node()
		{
			student = null;
			next = null;
		}
		
		public Node(Student student, Node next)
		{
			this.student = student;
			this.next = next;
		}
		
		public Node(Student student)
		{
			this.student = student;
			this.next = null;
		}
		
		
		
	}
	private Node head;
	private int size;
	private ArrayList<Student> removedStudents; // whoa! a data structure inside a data structure!
	
	/**
	 * description: sets head to null, size to 0, and initializes an array of removed students
	 */
	public WaitlistLinkedList()
	{
		head = null;
		size = 0;
		removedStudents = new ArrayList<Student>();
	}
	
	/**
	 * 
	 * Description: returns the name of the student at the given index in the LinkedList
	 * @param index
	 * @return String
	 */
	public String getStudentName(int index)
	{
		return this.getNode(index).student.getName();
	}
	
	
	/**
	 * 
	 * Description: returns the Node at the given index
	 * @param index
	 * @return Node
	 */
	public Node getNode(int index)
	{
		if(this.isValidIndex(index) == false)
		{
			System.out.println("Invalid index!!!");
			return null;
		}
		Node current  = head;
		int i = 0; 
		while(i < index && current != null)
		{
			current = current.next;
			i++;
		}
		return current;
	}
	
	/**
	 * 
	 * Description: adds the student after a given node
	 * @param student
	 * @param node
	 */
	public void addLast(Student student)
	{
		if(this.size == 0)
		{
			head = new Node(student);
		}
		else
		{
			Node lastNode = this.getNode(getSize()-1);
			lastNode.next = new Node(student, lastNode.next);
			
		}
		size++;
	}
	
	/**
	 * 
	 * Description: adds the given student to the front of the LinkedList 
	 * @param student
	 */
	public void addFirst(Student student)
	{
		if(size != 0)
		{	
			head = new Node(student, head);
		}
		else
		{

			head = new Node(student);
		}
		
		size++;
	}
		
	/**
	 * 
	 * Description: adding a new student at a specific index 
	 * @param index
	 * @param student
	 */
	//used, but in waitlisters, usually waitlisters are either inserted at the beginnning or the end
	public void add (int index, Student student) 
	{
		if (index == 0) 
		{
			addFirst(student);
		} 
		else
		{
			Node node = getNode(index-1);
			addAfter(node, student);
		}
	}
	
	/**
	 * 
	 * Description: for adding a student after another one. 
	 * @param node
	 * @param student
	 */
	private void addAfter(Node node, Student student) 
	{
		node.next = new Node(student, node.next);
		size++;
	}

	/**
	 * 
	 * Description: Removes a node after the given node.
	 * @param node
	 * @return Student
	 */
	private Student removeAfter (Node node)
	{
		//the node we are about to delete
		Node temp = node.next;
		if (temp != null) 
		{
			//basically saying : node.next = node.next.next
			node.next = temp.next;
			size--;
			
			//add the removed student to the array
			removedStudents.add(temp.student);
			
			//return the student you just removed
			return temp.student;
		} 
		else 
		{
			//if the node is currently at the end of the list, then don't do anything
			return null;
		}
	}
	
	/**
	 * 
	 * Description: removes the first node in the list
	 * @return Student
	 */
	private Student removeFirst() 
	{
		//for if the list is empty
		if (head == null) 
		{
			return null;
		} 
		else 
		{
			Node temp = this.head;
			head = head.next;
			size--;
			
			//add the removed student to the array
			removedStudents.add(temp.student);
			
			return temp.student;
		}
	}
	
	/**
	 * 
	 * Description: removes the student according to the given student
	 * Pre-condition: Student should exist if removing
	 * @param student
	 */
	public void remove(Student student)
	{
		boolean found = false;
		int index = 0;
		for(int i = 0; i < this.getSize(); i++)
		{
			if(student.equals(this.getNode(index).student))
			{
				found = true;
				break;
			}
			index++;
		}
		if(found == true)
		{
			if(index == 0)
			{
				this.removeFirst();
			}
			else
			{
				this.removeAfter(this.getNode(index-1));
			}
		}
		
		
	}
	
	//overloaded method yo
	/**
	 * 
	 * Description: remove a student at the given node
	 * Pre-condition: Student should exist if removing
	 * @param node
	 */
	public void remove(Node node)
	{
		Student student = node.student;
		boolean found = false;
		int index = 0;
		for(int i = 0; i < this.getSize(); i++)
		{
			if(student.equals(this.getNode(index).student))
			{
				found = true;
				break;
			}
			index++;
		}
		if(found == true)
		{
			if(index == 0)
			{
				this.removeFirst();
			}
			else
			{
				this.removeAfter(this.getNode(index-1));
			}
		}
		
		
	}
	
	/**
	 * 
	 * Description: sets a new student to a spot in the line
	 * @param index
	 * @param student
	 * @return Student
	 */
	public Student set (int index, Student student) 
	{
		if (isValidIndex(index) == true)
		{
			return null;
		}
			Node node = getNode(index);
			Student result = node.student;
			node.student = student;
			return result;
		}
	
	
	/**
	 * 
	 * Description: returns the size of the linked list 
	 * @return
	 */
	public int getSize()
	{
		return this.size;
	}
	
	/**
	 * 
	 * Description: returns all the students that were removed from the waitlist 
	 * @return String
	 */
	public String getRemovedStudents()
	{
		String result = "";
		for(int i = 0; i < this.removedStudents.size(); i++)
		{
			result += this.removedStudents.get(i) + "\n*********";
		}
		return result;
	}

	/**
	 * 
	 * Description: get all the students still remaining on the waitlist
	 * @return
	 */
	public String getWaitlisters()
	{
		String result = "";
		for(int i = 0; i < this.size; i++)
		{
			result += this.getNode(i).student + "\n*********";
		}
		return result;
	}
	/**
	 * 
	 * Description: checks if the given index exists in the list
	 * @param index
	 * @return boolean
	 */
	public boolean isValidIndex(int index)
	{
		if(index < 0 || index >= size)
		{
			return false;
		}
		else
		{
			return true;	
		}
	}
}
