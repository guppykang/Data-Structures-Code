package edu.miracosta.CS113;

public class HelloWorld {
	public static void main(String[] args)
	{
		System.out.println("Hello World");
		System.out.println("Oh my god It actually workds");
	}
		
}
