/**
 * Contain source code for Hello World demo
 */
/**
 * @author W7224261
 *
 */
package edu.miracosta.CS113;